<?php include "main_headers.php";?>
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<body>
<?php include "main_navs.php";?>
</div>


<style>
    
ul {
  list-style: none;
}
</style>


<div class ="container">
</br></br>
<ul>
<h3>New Messages </h3>
</ul>

</div>

</div>
<div class ="container">
<ul>
<hr class ="new1"> </hr>
<span onclick="this.parentElement.style.display='none'" class="w3-bar-item w3-button w3-white w3-xlarge w3-right"><i class="fa fa-trash" aria-hidden="true"></i></span>
<li> <a href = "/message.php">Subject of Message 1 by Username </a>

</br></br>

<hr class ="new1"> </hr>
<span onclick="this.parentElement.style.display='none'" class="w3-bar-item w3-button w3-white w3-xlarge w3-right"><i class="fa fa-trash" aria-hidden="true"></i></span>

<li> <a href = "/message.php">Subject of Message 2 by Username  </a>
</br></br>

<hr class ="new1"> </hr>
<span onclick="this.parentElement.style.display='none'" class="w3-bar-item w3-button w3-white w3-xlarge w3-right"><i class="fa fa-trash" aria-hidden="true"></i></span>

<li> <a href = "/message.php">Subject of Message 3 by Username  </a>
</br></br>

<h3>Deleted Messages </h3>

<hr class ="new1"> </hr>
<span onclick="this.parentElement.style.display='none'" class="w3-bar-item w3-button w3-white w3-xlarge w3-right"><i class="fa fa-trash" aria-hidden="true"></i></span>

<li> <a href = "/message.php">Subject of Message 4 by Username  </a>
</br></br>

<hr class ="new1"> </hr>
<span onclick="this.parentElement.style.display='none'" class="w3-bar-item w3-button w3-white w3-xlarge w3-right"><i class="fa fa-trash" aria-hidden="true"></i></span>

<li> <a href = "/message.php">Subject of Message 5 by Username  </a>
</br></br>
<h3>Warning Messages </h3>
<hr class ="new1"> </hr>
<span onclick="this.parentElement.style.display='none'" class="w3-bar-item w3-button w3-white w3-xlarge w3-right"><i class="fa fa-trash" aria-hidden="true"></i></span>
<li> <a href = "/message.php">Subject of Message 6 by Username  </a>
</br></br>

</ul>
</div>












</body>

</html>